Official LaTeX Beamer presentation template of the
Machine Learning and Optimisation (MALEO) group
University of Paderborn (UPB)
===

**Author**: Jakob Bossek (jakob.bossek@uni-paderborn.de)

Version history
===


* v1.2.1 [2024/12/21] Fixes:
    * Fix issue with \refer{} macros changing font-size to footnotesize permanently
    * Changes alert-color to UPB-pink for consistency with the alertblock title color
* v1.2.0 [2024/12/15] Various additions:
    * New bgimageframe frame type for slides with centered text and space-filling background image
    * New twocolframe frame type for two equally sized columns
    * Now macros, e.g., \twocol{}{}
    * Added UPB color theme (using UPBs secondary color blue as main color)
* v1.1.0 [2024/07/21] More modern title page
* v1.0.1 [2023/12/18] Modified color of citations (now light gray)
* v1.0.0 [2023/11/16] First
